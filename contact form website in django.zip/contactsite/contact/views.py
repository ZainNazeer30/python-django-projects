from django.core.mail import send_mail
from django.shortcuts import render
from .forms import ContactForm

def contact_view(request):
    form = ContactForm()
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            send_mail(
                f"Message from {cd['name']}",
                cd['message'],
                cd['email'],
                ['your_email@gmail.com'],
            )
            return render(request, 'contactapp/success.html', {'name': cd['name']})
    return render(request, 'contactapp/contact.html', {'form': form})
