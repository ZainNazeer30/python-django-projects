from django.urls import path
from .views import calc_views
urlpatterns = [
    path('', calc_views, name='calculator'),
]
